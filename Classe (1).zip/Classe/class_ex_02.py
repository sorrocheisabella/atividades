from class_ex_01 import Animais_Marinhos

animais = [
    Animais_Marinhos("Golfinho", "Mamífero", "Boto-cor-de-rosa", "Médio", "Carnívoro"),
    Animais_Marinhos("Tubarão-branco", "Peixe cartilaginoso", "Carcharodon carcharias", "Grande", "Carnívoro"),
    Animais_Marinhos("Baleia-azul", "Mamífero", "Balaenoptera musculus", "Gigante", "Planctívoro"),
    Animais_Marinhos("Polvo", "Molusco", "Octopus vulgaris", "Médio", "Carnívoro"),
    Animais_Marinhos("Cavalo-marinho", "Peixe ósseo", "Hippocampus", "Pequeno", "Carnívoro"),
    Animais_Marinhos("Estrela-do-mar", "Equinodermo", "Asteroidea", "Pequeno", "Carnívoro"),
    Animais_Marinhos("Tartaruga-marinha", "Réptil", "Cheloniidae", "Grande", "Herbívoro"),
    Animais_Marinhos("Arraia-jamanta", "Peixe cartilaginoso", "Manta birostris", "Grande", "Planctívoro"),
    Animais_Marinhos("Caranguejo", "Crustáceo", "Brachyura", "Pequeno", "Onívoro"),
    Animais_Marinhos("Lagosta", "Crustáceo", "Nephropidae", "Médio", "Carnívoro"),
    Animais_Marinhos("Peixe-palhaço", "Peixe ósseo", "Amphiprion ocellaris", "Pequeno", "Onívoro"),
    Animais_Marinhos("Peixe-leão", "Peixe ósseo", "Pterois", "Médio", "Carnívoro"),
    Animais_Marinhos("Orca", "Mamífero", "Orcinus orca", "Grande", "Carnívoro"),
    Animais_Marinhos("Lula-gigante", "Molusco", "Architeuthis dux", "Gigante", "Carnívoro"),
    Animais_Marinhos("Siri", "Crustáceo", "Callinectes sapidus", "Pequeno", "Onívoro"),
    Animais_Marinhos("Anchova", "Peixe ósseo", "Engraulidae", "Pequeno", "Carnívoro"),
    Animais_Marinhos("Coral", "Cnidário", "Anthozoa", "Pequeno", "Plâncton"),
    Animais_Marinhos("Medusa", "Cnidário", "Scyphozoa", "Médio", "Carnívoro"),
    Animais_Marinhos("Foca", "Mamífero", "Pinnipedia", "Médio", "Carnívoro"),
    Animais_Marinhos("Leão-marinho", "Mamífero", "Otariidae", "Médio", "Carnívoro")
]