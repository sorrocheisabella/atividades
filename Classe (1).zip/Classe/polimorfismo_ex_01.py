from herança_ex_01 import Personagens

class Serie(Personagens):
    def descrever(self):
        print(f"Sou {self.personagem}, e faço parte {self.participa} tenho {self.idade} anos.")

personagens = [
        Serie("Scott McCall", "Teen Wolf", 16, "Masculino"),
    Serie("Stiles Stilinski", "Teen Wolf", 16, "Masculino"),
    Serie("Derek Hale", "Teen Wolf", 22, "Masculino"),
    Serie("Lydia Martin", "Teen Wolf", 17, "Feminino"),
    Serie("Allison Argent", "Teen Wolf", 17, "Feminino"),
    Serie("Malia Tate", "Teen Wolf", 18, "Feminino"),
]

for p in personagens:
    p.descrever()